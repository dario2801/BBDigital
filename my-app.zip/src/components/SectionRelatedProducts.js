import React from "react";
import imagenes from "../assets/imagenes";

const SectionRelatedProducts = ({ categories, description, price }) => {
    
  return (
    <React.Fragment>
      <section
        className="container d-block mx-auto my-3 py-3"
        id="related-products"
      >
        <span className="sections d-block text-center">Related Products</span>
        <img
          className="d-block mx-auto"
          src={imagenes.guion}
          alt="image.jpg"
        ></img>

        <div className="row container mt-5">
          <div className="col-12">
            <div className="row d-flex mx-auto " style={{ maxWidth: "85%" }}>
              <div className="col-3 col-3">
                <img
                  className="img-fluid related-products d-block mx-auto hover"
                  src={imagenes.chica1}
                  alt="related-img.jpg"
                />
              </div>
              <div className="col-3 col-3">
                <img
                  className="img-fluid related-products d-block mx-auto hover"
                  src={imagenes.chica2}
                  alt="related-img.jpg"
                />
              </div>
              <div className="col-3 col-3">
                <img
                  className="img-fluid related-products d-block mx-auto hover"
                  src={imagenes.chica3}
                  alt="related-img.jpg"
                />
              </div>
              <div className="col-3 col-3">
                <img
                  className="img-fluid related-products d-block mx-auto hover"
                  src={imagenes.chica4}
                  alt="related-img.jpg"
                />
              </div>
            </div>
          </div>
          <div className="col-12 text-center">
            <div
              className="row d-flex mx-auto text-center "
              style={{ maxWidth: "85%" }}
            >
              <div className="col-3">
                <span className="girls">{categories}</span>
              </div>
              <div className="col-3">
                <span className="girls">{categories}</span>
              </div>
              <div className="col-3">
                <span className="girls">{categories}</span>
              </div>
              <div className="col-3">
                <span className="girls">{categories}</span>
              </div>
            </div>
          </div>
          <div className="col-12">
            <div
              className="row d-flex mx-auto text-center "
              style={{ maxWidth: "85%" }}
            >
              <div className="col-3">
                <span className="Gilda_Display">{description}</span>
              </div>
              <div className="col-3">
                <span className="Gilda_Display">{description}</span>
              </div>
              <div className="col-3">
                <span className="Gilda_Display">{description}</span>
              </div>
              <div className="col-3">
                <span className="Gilda_Display">{description}</span>
              </div>
            </div>
          </div>
          <div className="col-12">
            <div
              className="row d-flex mx-auto text-center"
              style={{ maxWidth: "85%" }}
            >
              <div className="col-3">
                <span className='price'>${price}</span>
              </div>
              <div className="col-3">
                <span className='price'>${price}</span>
              </div>
              <div className="col-3">
                <span className='price'>${price}</span>
              </div>
              <div className="col-3">
                <span className='price'>${price}</span>
              </div>
            </div>
          </div>
          <div className="col-12"></div>
        </div>
      </section>
    </React.Fragment>
  );
};
export default SectionRelatedProducts;
