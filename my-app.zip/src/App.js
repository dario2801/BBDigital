import Home from "./Home";
import DetailsWeb from "./DetailsWeb";
import { BrowserRouter, Route, Routes } from "react-router-dom";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/product/:id" element={<DetailsWeb/>} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
