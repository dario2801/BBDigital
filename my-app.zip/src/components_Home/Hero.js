import React from "react";
import imagenes from "../assets/imagenes";

const Hero = () => {
  return (
    <React.Fragment>
      <section className="container-fluid my-5">
        <div className="container">
          <div
            className="row mx-auto  justify-content-between"
            style={{ width: "100%", height: "auto" }}
          >
            <div className="col-8 container">
              <img
                src={imagenes.slider}
                alt="image.jpg"
                className=" img-fluid"
              ></img>
              <div className="jumpsuits ps-2">
                <span className="first d-block">JUMPSUITS</span>
                  <span className="second d-block">
                    Confortable clothes for your little babies
                  </span>
                <div className="contenedor">
                  <a className="discoverLink" href="#">
                    DISCOVER
                  </a>
                </div>
              </div>
            </div>
            <div className="col-4">
              <img
                src={imagenes.girlsPower}
                alt="image.jpg"
                className=" img-fluid"
              ></img>
              <div className="container-fluid d-block justify-content-center">
                <a className="girlpower d-block text-center mt-3" href="#">
                  GIRL POWER
                </a>
                <span className="summer mt-0 d-block text-center">
                  For a colorful summer
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container-fluid mt-5">
        <div className="container">
            <div className="row mx-auto bordes" style={{width: "100%", height:"auto"}}>
                <div className="col-3 py-3">
                    <div className="row justify-content-around text-center">
                        <img src={imagenes.baby} alt="image.jpg" className="d-block img-fluid circle h-auto"
                            style={{width: "154px"}}></img>
                        <a href="#" className="d-block mt-3">Baby & Toddler</a>
                    </div>
                </div>
                <div className="col-3 py-3">
                    <div className="row justify-content-around text-center">
                        <img src={imagenes.girl} alt="image.jpg" className="d-block img-fluid circle h-auto"
                            style={{width: "154px"}}></img>
                        <a href="#" class="d-block mt-3">For Girls</a></div>
                </div>
                <div className="col-3 py-3">
                    <div className="row justify-content-around text-center">
                        <img src={imagenes.boy} alt="image.jpg" class="d-block img-fluid circle h-auto"
                            style={{width: "154px"}}></img>
                        <a href="#" className="d-block mt-3">For Boys</a></div>
                </div>
                <div className="col-3 py-3">
                    <div className="row justify-content-around text-center">
                        <img src={imagenes.toys} alt="image" className="d-block img-fluid circle h-auto"
                            style={{width: "154px"}}></img>
                        <a href="#" className="d-block mt-3">Home & Toys</a></div>
                </div>
            </div>
        </div>
    </section>
      
    </React.Fragment>
  );
};

export default Hero;
