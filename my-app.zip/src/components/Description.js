import React from "react"
const Description =({category,description})=>{
   return (
      <React.Fragment>
          <div className="container-fluid py-5 bordes d-block mx-auto">
                <div className="row text-center mx-auto">
                <span className="sections d-block description pt-2">{description}</span>
                <span className="sections d-block">Home: {category} : {description}</span>
                </div>
            </div>
         </React.Fragment>
   )
}
export default Description;