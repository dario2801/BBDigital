import React from "react";
import imagenes from "../assets/imagenes";

const Aside = () => {
  return (
    <React.Fragment>
 <section className="container-fluid mt-5">
 <div className="container text-center" style={{width: "100%", height:"auto"}}>
     <span className="sections d-block">INSTAGRAM @KIDSRUN</span>
     <img src={imagenes.guion} alt="image.jpg"></img>
     <div className="row  mt-5">
         <div className="col-12 py-3">
             <div className="col-2 d-inline-block mx-auto" style={{width:"140px",height:"140px"}}><img
                     src={imagenes.aside1} alt="imge.jpg"
                     className="img-fluid hover"></img></div>
             <div className="col-2 d-inline-block mx-auto" style={{width:"140px",height:"140px"}}><img
                     src={imagenes.aside2} alt="imge.jpg"
                     className="img-fluid hover"></img></div>
             <div className="col-2 d-inline-block mx-auto" style={{width:"140px",height:"140px"}}><img
                     src={imagenes.aside3} alt="imge.jpg"
                     className="img-fluid hover"></img></div>
             <div className="col-2 d-inline-block" style={{width:"140px",height:"140px"}}><img
                     src={imagenes.aside4} alt="imge.jpg"
                     className="img-fluid hover"></img></div>
             <div className="col-2 d-inline-block" style={{width:"140px",height:"140px"}}><img
                     src={imagenes.aside5} alt="imge.jpg"
                     className="img-fluid hover"></img></div>
         </div>
     </div>
 </div>
</section>
</React.Fragment>
  );
};

export default Aside;
