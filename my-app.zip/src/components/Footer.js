import React from "react";
import imagenes from '../assets/imagenes';

const Footer = () => {
    return (
        <React.Fragment>
            <footer className=" container-fluid">
                <div class="row footer" style={{ height: "auto" }}>
                    <div className="wave"></div>
                    <div className="col-12 pt-5">
                        <img src={imagenes.logoF} className="d-block mx-auto" alt="logotype.jpg" style={{ width: "180px", height: "auto" }}></img>
                    </div>
                    <div className="col-12">
                        <ul className="nav justify-content-center pt-3">
                            <li className="nav-item">
                                <a className="nav-link  text-white" href="#">HOME</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link  text-white" href="#">SHOP</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link  text-white" href="#">SALE</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link  text-white" href="#">GIRLS</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link  text-white" href="#">BOYS</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link  text-white " href="#">LOOKBOOK</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link  text-white " href="#">CONTACTS</a>
                            </li>
                        </ul>
                    </div>


                    <div className="col-12">
                        <ul className="nav justify-content-center pt-3" style={{ fontSize: "120%" }}>
                            <li className="nav-item">
                                <a className="nav-link  text-white" href="#"><i className="fa fa-facebook"></i></a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link  text-white" href="#"><i className="fa fa-instagram"></i></a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link  text-white" href="#"><i className="fa fa-twitter"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div className="col-12">
                        <p className="text-center pt-3 text-white-50" style={{ fontSize: "72%" }}>
                            <span className="text-white">Privacy Policy/</span> This is a sample website - cmsmasters © 2022 / All Rights Reserved
                        </p>
                    </div>
                </div>
            </footer>
        </React.Fragment>
    )
}
export default Footer;