import React from "react";
import imagenes from "../assets/imagenes";

const Reviews = ({
  color,
  materials,
  age,
}
) => {
  return (
    <React.Fragment>
      <section className="container d-block mx-auto my-3 py-3">
        <div className="row container justify-content-center">
          <ul className="nav  justify-content-center" id="myTab" role="tablist">
            <li className="nav-item sections" role="presentation">
              <button
                className="nav-link active buttonPersonalize"
                id="home-tab"
                data-bs-toggle="tab"
                data-bs-target="#home"
                type="button"
                role="tab"
                aria-controls="home"
                aria-selected="true"
              >
                <span> DESCRIPTION</span>
              </button>
            </li>
            <li className="nav-item sections" role="presentation">
              <button
                className="nav-link buttonPersonalize"
                id="profile-tab"
                data-bs-toggle="tab"
                data-bs-target="#profile"
                type="button"
                role="tab"
                aria-controls="profile"
                aria-selected="false"
              >
                <span>ADDITIONAL INFORMATION</span>
              </button>
            </li>
            <li className="nav-item sections" role="presentation">
              <button
                className="nav-link buttonPersonalize"
                id="messages-tab"
                data-bs-toggle="tab"
                data-bs-target="#messages"
                type="button"
                role="tab"
                aria-controls="messages"
                aria-selected="false"
              >
                <span>REVIEWS(1)</span>
              </button>
            </li>
          </ul>

          <div className="tab-content">
            <div
              className="tab-pane active my-5"
              id="home"
              role="tabpanel"
              aria-labelledby="home-tab"
              tabindex="0"
            >
              <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                Delectus, unde porro debitis soluta veritatis perspiciatis, iste
                eaque id atque expedita nam! Inventore tenetur, quia commodi
                asperiores deserunt laboriosam aliquid, porro voluptatibus
                autem, magnam natus? Error officiis hic enim minima praesentium
                obcaecati inventore, architecto deleniti sequi reprehenderit
                voluptate iure molestiae nulla!
              </p>
              <br />
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolor,
                voluptate quasi nemo minima eveniet doloribus facere, veniam
                cupiditate cum facilis blanditiis! Voluptatum mollitia, a eos
                praesentium excepturi pariatur nemo, voluptate, laborum illo
                dolore quaerat culpa. Quaerat dolore quis minima, voluptatibus
                nemo labore repudiandae placeat molestias eos similique hic,
                aperiam ipsa consequatur. Quos inventore qui maxime corporis
                enim, corrupti nam omnis minima debitis quasi vero placeat
                sapiente! Vero dolorum earum recusandae accusantium reiciendis?
                Dolorum nisi nesciunt facere rem quis ducimus exercitationem?
              </p>
            </div>
            <div
              className="tab-pane"
              id="profile"
              role="tabpanel"
              aria-labelledby="profile-tab"
              tabindex="0"
            >
              <table className="table table-border bordes my-5">
                <tbody>
                  <tr>
                    <td>
                      <a href="#">Color:</a>
                    </td>
                    <td>{color}</td>
                  </tr>
                  <tr>
                    <td>
                      <a href="#">Materials:</a>
                    </td>
                    <td>{materials}</td>
                  </tr>
                  <tr>
                    <td>
                      <a href="#">Age:</a>
                    </td>
                    <td>{age}</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div
              className="tab-pane"
              id="messages"
              role="tabpanel"
              aria-labelledby="messages-tab"
              tabindex="0"
            ></div>
          </div>
        </div>
      </section>
    </React.Fragment>
  );
};

export default Reviews;
