import React from "react";
import imagenes from "../assets/imagenes";
import {PRODUCTS} from '../Category';
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

//funcion para mostrar todos los elementos de una categoria seleccionada
function getProducts (PRODUCTS, category){
  if (category === ""){
    return randomProducts(PRODUCTS)
  }
  var p = PRODUCTS.filter(itemToCompare => {
    if (category === 'For Home'){
      return itemToCompare.category === 'For Home' || itemToCompare.category === 'For Toys' 
    } else {
      return itemToCompare.category === category
    }
  })
  var r = p.map( item => 
    ( <div className="col-4">
     <Link to={`/product/${item.id}`}>
    <img
    src={(item.img1)}
    alt="images.jpg"
    className="img-fluid"
    ></img></Link>
    <div className='py-2 animation' style={{background:'coral',position:'relative'}}>
      <div className='bordes mx-3 py-2'>
    <i className='fa fa-heart me-3 colorIcon'></i><span style={{fontFamily:'Francois_One'}}>ADD TO CAR</span><i className=' colorIcon fa fa-search ms-3'></i>
    </div>
    </div>
    <div className="mt-2"><span className='Francois_One color'>{item.category}</span></div>
    <div><span className='Gilda_Display'> {item.description}</span></div>
    <div className="mb-3"> <span className='price'>${item.price}</span></div>
    </div>)
  
    )
  return r
}

// Funcion para generar productos randoms (9)
function randomProducts(PRODUCTS){
  const x = PRODUCTS.sort(() => Math.random() > 0.5 ? 1 : -1);
  const imgRandom = PRODUCTS.slice(0,9);
    return imgRandom.map((item)=>(
    <div className="col-4">
     <Link to={`/product/${item.id}`}>
    <img
    src={(item.img1)}
    alt="images.jpg"
    className="img-fluid"
    ></img></Link>
    <div className='py-2 animation' style={{background:'coral',position:'relative'}}>
      <div className='bordes mx-3 py-2'>
    <i className='fa fa-heart me-3 colorIcon'></i><span style={{fontFamily:'Francois_One'}}>ADD TO CAR</span><i className=' colorIcon fa fa-search ms-3'></i>
    </div>
    </div>
    <div className="mt-2"><span className='Francois_One color'>{item.category}</span></div>
    <div><span className='Gilda_Display'> {item.description}</span></div>
    <div className="mb-3"> <span className='price'>${item.price}</span></div>
    </div>
    ))
}

class Arrivlas extends React.Component {
  constructor (props) {
    super(props)
    this.state = {products: getProducts(PRODUCTS, "")}
  }

  render() {
    return (
        <div>
          
          <section className="container-fluid my-5">
                  <div className="container">
                    <div
                      className="row mx-auto  justify-content-between"
                      style={{ width: "100%", height: "auto" }}
                    >
                      <div className="col-8 container">
                        <img
                          src={imagenes.slider}
                          alt="image.jpg"
                          className=" img-fluid"
                        ></img>
                        <div className="jumpsuits ps-2">
                          <span className="first d-block">JUMPSUITS</span>
                            <span className="second d-block">
                              Confortable clothes for your little babies
                            </span>
                          <div className="contenedor">
                            <a className="discoverLink" href="#">
                              DISCOVER
                            </a>
                          </div>
                        </div>
                      </div>
                      <div className="col-4">
                        <img
                          src={imagenes.girlsPower}
                          alt="image.jpg"
                          className=" img-fluid"
                        ></img>
                        <div className="container-fluid d-block justify-content-center">
                          <a className="girlpower d-block text-center mt-3" href="#">
                            GIRL POWER
                          </a>
                          <span className="summer mt-0 d-block text-center">
                            For a colorful summer
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
          
                <section className="container-fluid mt-5">
                  <div className="container">
                      <div className="row mx-auto bordes" style={{width: "100%", height:"auto"}}>
                          <div className="col-3 py-3" onClick={()=> this.setState({products: getProducts(PRODUCTS, "For Babies")})}>
                              <div className="row justify-content-around text-center"  >
                                  <img src={imagenes.baby} alt="image.jpg"   className="d-block img-fluid circle h-auto"
                                      style={{width: "154px"}}></img>
                                  <a href="#" className="d-block mt-3">Baby & Toddler</a>
                              </div>
                          </div>
                          <div className="col-3 py-3" onClick={()=> this.setState({products: getProducts(PRODUCTS, "For Girls")})}> 
                              <div className="row justify-content-around text-center">
                                  <img src={imagenes.girl} alt="image.jpg" className="d-block img-fluid circle h-auto"
                                      style={{width: "154px"}}></img>
                                  <a href="#" class="d-block mt-3">For Girls</a></div>
                          </div>
                          <div className="col-3 py-3" onClick={()=> this.setState({products: getProducts(PRODUCTS, "For Boys")})}> 
                              <div className="row justify-content-around text-center">
                                  <img src={imagenes.boy} alt="image.jpg" class="d-block img-fluid circle h-auto"
                                      style={{width: "154px"}}></img>
                                  <a href="#" className="d-block mt-3">For Boys</a></div>
                          </div>
                          <div className="col-3 py-3" onClick={()=> this.setState({products: getProducts(PRODUCTS, "For Home")})}> 
                              <div className="row justify-content-around text-center">
                                  <img src={imagenes.toys} alt="image" className="d-block img-fluid circle h-auto"
                                      style={{width: "154px"}}></img>
                                  <a href="#" className="d-block mt-3">Home & Toys</a></div>
                          </div>
                      </div>
                  </div>
              </section>
                <section className="container-fluid mt-5">
                  <div
                    className="container text-center mx-auto"
                    style={{ width: "100%", height: "auto" }}
                  >
                    <span className="sections d-block">NEW ARRIVALS</span>
                    <img src={imagenes.guion} alt="image.jpg"></img>
                    <div className="row  mt-3">
                      <div className="col-3" style={{ height: "auto" }}>
                        <form action="" className="navbar-form navbar-left">
                          <div className="input-group">
                            <input
                              type="Search"
                              placeholder="Search products..."
                              className="form-control"
                            />
                            <div className="searchBackground">
                              <i className="fa fa-search search py-2 px-2"></i>
                            </div>
                          </div>
                        </form>
                        <div className="row container-fluid text-start">
                          <span className="sections ms-0 my-3">CATEGORIES</span>
                          <div className="bordes py-3">
                            <div className="row">
                              <div className="col-6 ">
                                <a href="#" class="text-start">
                                  For Babies
                                </a>
                              </div>
                              <div className="col-6 text-end">
                                <span>(11)</span>
                              </div>
                              <hr className="mt-2" />
                            </div>
          
                            <div className="row ">
                              <div className="col-6 ">
                                <a href="#" className="text-start">
                                  For Boys
                                </a>
                              </div>
                              <div className="col-6 text-end">
                                <span>(19)</span>
                              </div>
                              <hr className="mt-2" />
                            </div>
          
                            <div className="row ">
                              <div className="col-6 ">
                                <a href="#" class="text-start">
                                  For Girls
                                </a>
                              </div>
                              <div className="col-6 text-end">
                                <span>(20)</span>
                              </div>
                              <hr className="mt-2" />
                            </div>
          
                            <div className="row">
                              <div className="col-6 ">
                                <a href="#" class="text-start">
                                  For Home
                                </a>
                              </div>
                              <div className="col-6 text-end">
                                <span>(14)</span>
                              </div>
                              <hr className="mt-2" />
                            </div>
          
                            <div className="row">
                              <div className="col-6 ">
                                <a href="#" class="text-start">
                                  For Play
                                </a>
                              </div>
                              <div className="col-6 text-end">
                                <span>(8)</span>
                              </div>
                            </div>
                          </div>
                        </div>
          
                        <div className="row container-fluid text-start ">
                          <span className="sections ms-0 my-3">BEST SELLERS</span>
                          <div className=" py-3 bordes">
                            <div className="row">
                              <div className="col-3 ">
                                <a href="#" class="text-start">
                                  <img
                                    src={imagenes.forHome1}
                                    alt="image.jpg"
                                    style={{
                                      width: "50px",
                                      height: "50px",
                                      borderRadius: "50%",
                                    }}
                                  ></img>
                                </a>
                              </div>
                              <div className="col-9 text-start mb-3">
                                <div class="row container-fluid">
                                  <div className="col-12">
                                    <a href="#">
                                      Rabbit Casket
                                    </a>
                                  </div>
                                  <div className="col-12">
                                    <a href="#">
                                      range 4
                                    </a>
                                  </div>
                                  <div className="col-12">
                                    <a href="#">
                                      $46.00
                                    </a>
                                  </div>
                                </div>
                              </div>
          
                            </div>
                            <div className="row mb-3">
                              <div className="col-3 ">
                                <a href="#" class="text-start">
                                  <img
                                    src={imagenes.girl6}
                                    alt="image.jpg"
                                    style={{
                                      width: "50px",
                                      height: "50px",
                                      borderRadius: "50%",
                                    }}
                                  ></img>
                                </a>
                              </div>
                              <div className="col-9 text-start">
                                <div className="row container-fluid">
                                  <div className="col-12">
                                    <a href="#">
                                    Yellow SweartShirt
                                    </a>
                                  </div>
                                  <div className="col-12">
                                    <a href="#" className="hover">
                                      range 4
                                    </a>
                                  </div>
                                  <div className="col-12">
                                    <a href="#">
                                      $38.00
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="row mb-3">
                              <div class="col-3 ">
                                <a href="#" className="text-start">
                                  <img
                                    src={imagenes.boy3}
                                    alt="image.jpg"
                                    style={{
                                      width: "50px",
                                      height: "50px",
                                      borderRadius: "50%",
                                    }}
                                  ></img>
                                </a>
                              </div>
                              <div className="col-9 text-start">
                                <div class="row container-fluid">
                                  <div className="col-12">
                                    <a href="#">
                                      Line Sweater
                                    </a>
                                  </div>
                                  <div className="col-12">
                                    <a href="#">
                                      range 4
                                    </a>
                                  </div>
                                  <div className="col-12">
                                    <a href="#">
                                      $46.00
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="row">
                              <div className="col-3 ">
                                <a href="#" className="text-start">
                                  <img
                                    src={imagenes.boy4}
                                    alt="image.jpg"
                                    style={{
                                      width: "50px",
                                      height: "50px",
                                      borderRadius: "50%",
                                    }}
                                  ></img>
                                </a>
                              </div>
                              <div className="col-9 text-start">
                                <div className="row container-fluid">
                                  <div className="col-12">
                                    <a href="#" className="hover">
                                      range 4
                                    </a>
                                  </div>
                                  <div className="col-12">
                                    <a href="#" className="hover">
                                      $80.00
                                    </a>
                                  </div>
                                  <div className="col-12">
                                    <a href="#" className="hover">
                                      Rabbit Casket
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="row container-fluid text-start ">
                          <div className=" py-3 ">
                            <div className="row mt-5">
                              <div
                                class="col-12 text-center pt-3 pb-3"
                                style={{ backgroundColor: "coral" }}
                              >
                                <span className="newletters">Join Our Newletter</span>
                                <form action="/action_page.php" className="text-start">
                                  <div className="mb-3 mt-3">
                                    <input
                                      type="email"
                                      className="form-control text-white"
                                      id="email"
                                      placeholder="Your Email Address"
                                      name="email"
                                      style={{ backgroundColor: "coral" }}
                                    ></input>
                                  </div>
                                </form>
                                <div className="col-12 envoltorio text-center py-1 px-1 bg-white">
                                  <span className="suscribe">
                                    <a href="#">SUSCRIBE</a>
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
          
          
                      <div className="col-9">
                        <div className="row mb-3" style={{ height: "auto" }}>
                          {
                          this.state.products
                          }
                        </div>
                      </div>
                    </div>
                  </div> 
              </section>
        </div>
    )
  }
}


export default Arrivlas;





// import Lista from "./dasdasd.json"

// var l = JSON.parse(Lista)

// //acceder al sku del primer producto de la primera categoria
// l.products[0].products[0].sku
// l.products[0].category === 'babies' 