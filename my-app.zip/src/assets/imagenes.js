
//MAIN
import logo from './main/logo.png';
import girls2 from './girls-2-2-580x870.jpg';
import girls21 from './girls-2-2-580x870.jpg';
import girls22 from './girls-2-3-580x870.jpg';
import guion from './main/home-8.png';
import chica1 from './girls-4-580x870.jpg';
import chica2 from './girls-7-580x870.jpg'
import chica3 from './girls-9-580x870.jpg';
import chica4 from './girls-10-580x870.jpg';
import logoF from './main/logo(1).png';
import loader from './main/loader.gif';
import slider from './main/slider-1.jpg'
import girlsPower from './main/girls-power.jpg'
import baby from './main/baby.png'
import girl from './main/girl.png'
import boy from './main/boy.png'
import toys from './main/toys.png'
import aside1 from './main/87339849_530805007551424_292323017375800029_nlow.jpg'
import aside2 from './main/87413583_2660130777540405_5722961474466513534_nlow.jpg'
import aside3 from './main/85069033_185901059177965_6767010623440980864_nlow.jpg'
import aside4 from './main/84981049_620107085435507_4260875787090681190_nlow.jpg'
import aside5 from './main/85051426_2060664737412512_8458893884651247910_nlow.jpg'
import girl6  from './main/girls-6-300x300.jpg'
import boy3   from './main/boys-3-1-300x300.jpg'
import boy4   from './main/boys-4-300x300.jpg'


// FOR_BABIES

import forbabies1 from './for babies/for-babies-1-580x870.jpg';
import forbabies101 from './for babies/for-babies-1-1-580x870.jpg';
import forbabies2 from './for babies/for-babies-2-580x870.jpg';
import forbabies21 from './for babies/for-babies-2-1-580x870.jpg';
import forbabies3 from './for babies/for-babies-3-580x870.jpg';
import forbabies31 from './for babies/for-babies-3-1-580x870.jpg';
import forbabies4 from './for babies/for-babies-4-580x870.jpg';
import forbabies41 from './for babies/for-babies-4-1-580x870.jpg';
import forbabies5 from './for babies/for-babies-5-580x870.jpg';
import forbabies51 from './for babies/for-babies-5-1-580x870.jpg';
import forbabies6 from './for babies/for-babies-6-580x870.jpg';
import forbabies61 from './for babies/for-babies-6-1-580x870.jpg';
import forbabies7 from './for babies/for-babies-7-580x870.jpg';
import forbabies71 from './for babies/for-babies-7-1-580x870.jpg';
import forbabies8 from './for babies/for-babies-8-580x870.jpg';
import forbabies81 from './for babies/for-babies-8-1-580x870.jpg';
import forbabies9 from './for babies/for-babies-9-580x870.jpg';
import forbabies91 from './for babies/for-babies-9-1-580x870.jpg';
import forbabies10 from './for babies/for-babies-10-580x870.jpg';
import forbabies1001 from './for babies/for-babies-10-1-580x870.jpg';
import forbabies11 from './for babies/for-babies-11-580x870.jpg';
import forbabies1101 from './for babies/for-babies-11-1-580x870.jpg';

//FOR_GIRLS
import forGirls1 from  './for girls/girls-1-1-580x870.jpg'
import forGirls12 from './for girls/girls-1-2-580x870.jpg'
import forGirls2 from  './for girls/girls-2-580x870.jpg'
import forGirls21 from './for girls/girls-2-2-580x870.jpg'
import forGirls22 from './for girls/girls-2-3-580x870.jpg'
import forGirls3 from  './for girls/girls-3-580x870.jpg'
import forGirls31 from './for girls/girls-3-1-580x870.jpg'
import forGirls32 from './for girls/girls-3-2-580x870.jpg'
import forGirls4 from  './for girls/girls-4-580x870.jpg'
import forGirls41 from './for girls/girls-4-1-580x870.jpg'
import forGirls42 from './for girls/girls-4-2-580x870.jpg'
import forGirls6  from './for girls/girls-6-1-580x870.jpg'
import forGirls61 from './for girls/girls-6-2-580x870.jpg'
import forGirls7  from './for girls/girls-7-580x870.jpg'
import forGirls71 from './for girls/girls-7-1-580x870.jpg'
import forGirls72 from './for girls/girls-7-2-580x870.jpg'
import forGirls8  from './for girls/girls-8-580x870.jpg'
import forGirls81 from './for girls/girls-8-1-580x870.jpg'
import forGirls82 from './for girls/girls-8-2-580x870.jpg'
import forGirls9  from './for girls/girls-9-580x870.jpg'
import forGirls10  from './for girls/girls-10-580x870.jpg'
import forGirls1001  from './for girls/girls-10-1-580x870.jpg'
import forGirls1002  from './for girls/girls-10-2-580x870.jpg'
import forGirls11    from './for girls/girls-11-1-580x870.jpg'
import forGirls1101    from './for girls/girls-11-2-580x870.jpg'

//FOR_HOME
import forHome1 from './for home/for-home-1-580x870.jpg'
import forHome12 from './for home/for-home-1-1-580x870.jpg'
import forHome2 from './for home/for-home-2-580x870.jpg'
import forHome22 from './for home/for-home-2-2-580x870.jpg'
import forHome3 from './for home/for-home-3-580x870.jpg'
import forHome31 from './for home/for-home-3-1-580x870.jpg'
import forHome4 from './for home/for-home-4-580x870.jpg'
import forHome5 from './for home/for-home-5-580x870.jpg'
import forHome51 from './for home/for-home-5-1-580x870.jpg'
import forHome6 from './for home/for-home-6-580x870.jpg'
import forHome7 from './for home/for-home-7-580x870.jpg'
import forHome71 from './for home/for-home-7-1-580x870.jpg'
import forHome8 from './for home/for-home-8-580x870.jpg'
import forHome81 from './for home/for-home-8-1-580x870.jpg'
import forHome9 from './for home/for-home-9-580x870.jpg'
import forHome91 from './for home/for-home-9-1-580x870.jpg'
import forHome10 from './for home/for-home-10-580x870.jpg'
import forHome1001 from './for home/for-home-10-1-580x870.jpg'
import forHome11 from './for home/for-home-11-580x870.jpg'
import forHome1101 from './for home/for-home-11-1-580x870.jpg'
import forHome1200 from './for home/for-home-12-580x870.jpg'
import forHome1201 from './for home/for-home-12-1-580x870.jpg'
import forHome1300 from './for home/for-home-13-580x870.jpg'
import forHome1301 from './for home/for-home-13-1-580x870.jpg'
import forHome1400 from './for home/for-home-14-580x870.jpg'
import forHome1401 from './for home/for-home-14-1-580x870.jpg'
import forHome1500 from './for home/for-home-15-580x870.jpg'
import forHome1501 from './for home/for-home-15-1-580x870.jpg'
import forHome1600 from './for home/for-home-16-580x870.jpg'
import forHome1601 from './for home/for-home-16-1-580x870.jpg'
import forHome from './main/for-home-15-300x300.jpg'


//FOR_BOYS
import forBoys1 from './for boys/boys-1-580x870.jpg'
import forBoys12 from './for boys/boys-1-1-580x870.jpg'
import forBoys2 from './for boys/boys-2-580x870(1).jpg'
import forBoys21 from './for boys/boys-2-1-580x870.jpg'
import forBoys3 from './for boys/boys-3-580x870.jpg'
import forBoys31 from './for boys/boys-3-1-580x870.jpg'
import forBoys4 from './for boys/boys-4-580x870.jpg'
import forBoys5 from './for boys/boys-4-1-580x870.jpg'
import forBoys6 from './for boys/boys-5-1-580x870.jpg'
import forBoys61 from './for boys/boys-5-580x870.jpg'
import forBoys7 from './for boys/boys-6-1-580x870.jpg'
import forBoys71 from './for boys/boys-6-580x870.jpg'
import forBoys8 from './for boys/boys-8-580x870.jpg'
import forBoys81 from './for boys/boys-8-1-580x870.jpg'
import forBoys9 from './for boys/boys-10-580x870.jpg'
import forBoys91 from './for boys/boys-10-1-580x870.jpg'
import forBoys10 from './for boys/boys-11-580x870.jpg'
import forBoys1001 from './for boys/boys-11-1-580x870.jpg'
import forBoys11 from './for home/for-home-11-580x870.jpg'


export default {
    //MAIN
    "logo": logo,
    "girls2": girls2,
    "girls21": girls21,
    "girls22": girls22,
    "guion": guion,
    "chica1": chica1,
    "chica2": chica2,
    "chica3": chica3,
    "chica4": chica4,
    "logoF": logoF,
    "loader":loader,
    "slider":slider,
    "girlsPower":girlsPower,
    "baby":baby,
    "girl":girl,
    "boy":boy,
    "toys":toys,
    "aside1":aside1,
    "aside2":aside2,
    "aside3":aside3,
    "aside4":aside4,
    "aside5":aside5,
    "girl6":girl6,
    "boy3":boy3,
    "boy4":boy4,

    // FOR_BABIES
    "forbabies1":forbabies1,
    "forbabies101":forbabies101,
    "forbabies2":forbabies2,
    "forbabies21":forbabies21,
    "forbabies3":forbabies3,
    "forbabies31":forbabies31,
    "forbabies4":forbabies4,
    "forbabies41":forbabies41,
    "forbabies5":forbabies5,
    "forbabies51":forbabies51,
    "forbabies6":forbabies6,
    "forbabies61":forbabies61,
    "forbabies7":forbabies7,
    "forbabies71":forbabies71,
    "forbabies8":forbabies8,
    "forbabies81":forbabies81,
    "forbabies9":forbabies9,
    "forbabies91":forbabies91,
    "forbabies10":forbabies10,
    "forbabies1001":forbabies1001,
    "forbabies11":forbabies11,
    "forbabies1101":forbabies1101,

    // FOR_GIRLS

    "forGirls1":forGirls1,
    "forGirls12":forGirls12,
    "forGirls2":forGirls2,
    "forGirls21":forGirls21,
    "forGirls22":forGirls22,
    "forGirls3":forGirls3,
    "forGirls31":forGirls31,
    "forGirls32":forGirls31,
    "forGirls33":forGirls32,
    "forGirls4":forGirls4,
    "forGirls41":forGirls41,
    "forGirls42":forGirls42,
    "forGirls6":forGirls6,
    "forGirls61":forGirls61,
    "forGirls7":forGirls7,
    "forGirls71":forGirls71,
    "forGirls72":forGirls72,
    "forGirls8":forGirls8,
    "forGirls81":forGirls81,
    "forGirls82":forGirls82,
    "forGirls9":forGirls9,
    "forGirls10":forGirls10,
    "forGirls1001":forGirls1001,
    "forGirls1002":forGirls1002,
    "forGirls11":forGirls11,
    "forGirls1101":forGirls1101,

    //FOR_HOME
    "forHome00":forHome1,
    "forHome12":forHome12,
    "forHome2":forHome2,
    "forHome22":forHome22,
    "forHome3":forHome3,
    "forHome31":forHome31,
    "forHome4":forHome4,
    "forHome5":forHome5,
    "forHome51":forHome51,
    "forHome6":forHome6,
    "forHome7":forHome7,
    "forHome71":forHome71,
    "forHome8":forHome8,
    "forHome81":forHome81,
    "forHome9":forHome9,
    "forHome91":forHome91,
    "forHome10":forHome10,
    "forHome1001":forHome1001,
    "forHome11":forHome11,
    "forHome1101":forHome1101,
    "forHome1200":forHome1200,
    "forHome1201":forHome1201,
    "forHome1300":forHome1300,
    "forHome1301":forHome1301,
    "forHome1400":forHome1400,
    "forHome1401":forHome1401,
    "forHome1500":forHome1500,
    "forHome1501":forHome1501,
    "forHome1600":forHome1600,
    "forHome1601":forHome1601,
    "forHome1":forHome,

    //FOR_BOYS
    "forBoys1":forBoys1,
    "forBoys12":forBoys12,
    "forBoys2":forBoys2,
    "forBoys21":forBoys21,
    "forBoys3":forBoys3,
    "forBoys31":forBoys31,
    "forBoys4":forBoys4,
    "forBoys5":forBoys5,
    "forBoys6":forBoys6,
    "forBoys61":forBoys61,
    "forBoys7":forBoys7,
    "forBoys8":forBoys8,
    "forBoys81":forBoys81,
    "forBoys9":forBoys9,
    "forBoys91":forBoys91,
    "forBoys10":forBoys10,
    "forBoys1001":forBoys1001,
    "forBoys11":forBoys11,
    "forBoys1001":forHome1001,
    "forBoys11":forHome11,
    "forBoys71":forBoys71,
    }

