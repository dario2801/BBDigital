import "./App.css";
import Header from "./components/Header";
import Description from "./components/Description";
import Footer from "./components/Footer";
import SectionDetails from "./components/SectionDetails";
import SectionRelatedProducts from "./components/SectionRelatedProducts";
import Reviews from "./components/Reviews";
import { useParams } from "react-router-dom";
import { PRODUCTS } from "./Category";

const DetailsWeb = () => {
  const { id } = useParams();
  const data = PRODUCTS.find((item) => item.id == id);
  return (
    <div className="App">
      <Header />
      <Description category={data.category} description={data.description} />
      <SectionDetails
        id={data.id}
        photos={[data.img1, data.img2,data.img3]}
        price={data.price}
        sex={data.sex}
        type={data.type}
        range={data.range}
        paragraph={data.paragraph}
        category={data.category}
      />
      <Reviews color={data.color} materials={data.material} age={data.age} />
      <SectionRelatedProducts
        category={data.category}
        description={data.description}
        price={data.price}
        isInStock={data.isInStock}
        range={data.range}
      />
      <Footer />
    </div>
  );
};

export default DetailsWeb;
