import React from "react";
import imagenes from "../assets/imagenes";
import { Link } from "react-router-dom";

const Header = () => {
  return (
    <React.Fragment>
      <header className="mainbar text-center text-white h-auto p-1">
        <span>
          20% off all kidswear + free shopping when you spend $60 or more
        </span>
      </header>

      <div className="container-fluid row">
        <div className="col">
          <img
            src={imagenes.logo}
            className="d-block mx-auto"
            alt="logotype.jpg"
          ></img>
        </div>
      </div>

      <div className="container-fluid my-3">
        <ul className="nav justify-content-center">
          <li className="nav-item">
            <Link className="nav-link" to={"/"}>
              HOME
            </Link>
            <img src={imagenes.guion} alt="guion.jpg"></img>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">
              SHOP FEATURES
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">
              CLOTHES
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">
              PAGES
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link" href="#">
              SHORTCODES
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link " href="#">
              POST TYPES
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link " href="#">
              <i class="fa fa-heart"></i>
            </a>
          </li>
      
          <li className="nav-item">
            <a className="nav-link " href="#">
              <i class="fa fa-search"></i>
            </a>
          </li>
        </ul>
      </div>
    </React.Fragment>
  );
};

export default Header;
