import logo from "./logo.svg";
import "./App.css";
import imagenes from "./assets/imagenes";
import { PRODUCTS } from "./Category";
import Header from "./components_Home/Header";
import Footer from "./components/Footer";
import ARRIVALS from './components_Home/Arrivals';
import Aside from './components_Home/Aside'
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="App">
      <Header/>
      <ARRIVALS/>
      <Aside/>
      <Footer/>
    </div>
  );
};

export default Home;
